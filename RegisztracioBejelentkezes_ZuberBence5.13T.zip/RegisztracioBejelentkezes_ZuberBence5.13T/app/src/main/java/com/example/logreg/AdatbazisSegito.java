package com.example.logreg;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;

public class AdatbazisSegito extends SQLiteOpenHelper {

    public static  final String Database_name="Felhasznalo.db";
    public static  final String Table_name="felhasznalo";


    public static  final String COL_1="ID";
    public static  final String COL_2="EMAIL";
    public static  final String COL_3="FELHASZNALONEV";
    public static  final String COL_4="JELSZÓ";
    public static  final String COL_5="TELJESNEV";

    public AdatbazisSegito(Context context)
    {
        super(context,Database_name,null,1);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL("CREATE TABLE "+Table_name+" (ID INTEGER PRIMARY KEY AUTOINCREMENT, KERESZTNEV TEXT,VEZETEKNEV TEXT,JEGY INTEGER)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS "+Table_name);
    }

    public boolean adatRogzites(String email,String felhasznalonev,String jelszo,String teljesnev)
    {
        SQLiteDatabase sqLiteDatabase=this.getWritableDatabase();
        ContentValues contentValues=new ContentValues();
        contentValues.put("COL_2",email);
        contentValues.put("COL_3",felhasznalonev);
        contentValues.put("COL_4",jelszo);
        contentValues.put("COL_4",teljesnev);

        long eredmeny=sqLiteDatabase.insert(Table_name,null,contentValues);

        if(eredmeny== -1)
        {
            return false;
        }
        else{
            return true;
        }


    }
    public Cursor adatLekerdezes()
    {
        SQLiteDatabase sqLiteDatabase=this.getWritableDatabase();
        return sqLiteDatabase.rawQuery("SELECT * from "+Table_name,null);

    }

}
